const express = require('express');
const app = express();

const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/starter_test');

const bcrypt = require('bcrypt');
const sr = 10;

const User = mongoose.model('User', {
  username: String,
  password: String,
  email: String,
  hasPaymentMethod: Boolean,
  subscriber: Boolean,
});

const Template = mongoose.model('Template', {
  name: String,
  dependencies: Array,
  version: String,
  bucket: String,
  filename: String,
  ownerType: String,
  owner: Object
})

app.use(express.json());
app.use(express.urlencoded({ extended: true, limit: '500mb' }));
app.use(express.json({ limit: '50mb' }));

app.post('/api/v1/register', (req, res) => {
  const userData = req.body;
  bcrypt.hash(req.body.password, sr, function(err, hash) {
    if (err) {
      throw err;
    } else {
      userData.password = hash;
      userData.hasPaymentMethod = false;
      userData.subscriber = false;
      const newUser = new User(userData);
      newUser.save().then((data) => res.json(data));
    }
  });
});

app.post('/api/v1/login', async(req, res) => {
  const userData = req.body;
  if (userData) {
    const userDb = await User.findOne({ username: userData.username });
    if (userDb !== null) {
      const authorized = await bcrypt.compare(userData.password, userDb.password);
      if (authorized) {
        res.status(200);
        res.json('Authenticated')
      } else {
        res.status(401);
        res.json('Unauthorized')
      }
    } else {
      res.status(422);
      res.json("These credentials don't seem right... Is this username valid?")
    }
  }
})

app.post('/api/v1/template', async(req, res) => {
  const templateData = req.body;
  const newTemplate = new Template(templateData);
  newTemplate.save().then((data) => res.json(data));
});

module.exports.app = app;
